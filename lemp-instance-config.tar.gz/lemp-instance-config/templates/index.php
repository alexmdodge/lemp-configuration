<?php

echo '<h1> Site Root </h1>'
phpinfo();