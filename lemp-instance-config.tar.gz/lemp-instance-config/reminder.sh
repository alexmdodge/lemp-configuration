#!/bin/bash

##
# Some important reminders for SSL certs
##

# Specific commands for certbot
echo "The following three commands will manage certs:"
echo "sudo certbot --nginx"
echo "sudo certbot renew --dry-run"
echo "certbot renew"
